<?php
session_start();
require_once 'config.php';
include 'header.php';
include 'ultimosalquileres.php';
require_once('footer.php');
?>
