<footer class="mt-4" style="background-color: #102C57; padding: 20px 0;"> <!-- Color más oscuro de la paleta -->
    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center text-md-left mb-3 mb-md-0">
                <p style="color: #F8F0E5;">&copy; <?php echo date("Y"); ?> RapiBnB</p> <!-- Color más claro de la paleta -->
            </div>
            <div class="col-md-6 text-center text-md-right">
                <a href="#" style="color: #EADBC8; margin-right: 10px;"><i class="bi bi-facebook" style="font-size: 24px;"></i></a> <!-- Segundo color de la paleta -->
                <a href="#" style="color: #EADBC8; margin-right: 10px;"><i class="bi bi-instagram" style="font-size: 24px;"></i></a> <!-- Segundo color de la paleta -->
                <a href="#" style="color: #EADBC8;"><i class="bi bi-twitter" style="font-size: 24px;"></i></a> <!-- Segundo color de la paleta -->
            </div>
        </div>
    </div>
</footer>
