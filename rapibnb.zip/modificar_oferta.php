<head>
	<link href="estilos/estilo.css" rel="stylesheet">
</head>

<?php
// Incluye el archivo de configuración de la base de datos y el encabezado
require_once('config.php');
require_once('header.php');

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["id"])) {
    // Si el usuario no ha iniciado sesión, redirigirlo a la página de inicio de sesión
    header("Location: login.php");
    exit();
}

// Verificar si se proporcionó un ID de oferta válido
if (isset($_GET["id"]) && is_numeric($_GET["id"])) {
    $id_oferta = $_GET["id"];

    // Consulta SQL para obtener detalles de la oferta y el ID del usuario que la creó
    $sql = "SELECT a.*, u.id AS usuario_id FROM alquileres a
            INNER JOIN usuarios u ON a.usuario_id = u.id
            WHERE a.id = ?";
    if ($stmt = mysqli_prepare($conexion, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $id_oferta);
        if (mysqli_stmt_execute($stmt)) {
            $resultado = mysqli_stmt_get_result($stmt);
            if (mysqli_num_rows($resultado) == 1) {
                $fila = mysqli_fetch_assoc($resultado);

                // Verificar si el usuario en sesión es el propietario de la oferta
                if (isset($_SESSION['id']) && $_SESSION['id'] == $fila['usuario_id']) {
                    // El usuario es el propietario, permitir la modificación
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        // Procesar el formulario de modificación de oferta cuando se envíe
                        // Obtener los datos del formulario
                        $titulo = $_POST["titulo"];
                        $descripcion = $_POST["descripcion"];
                        $ubicacion = $_POST["ubicacion"];
                        $etiquetas = $_POST["etiquetas"];
                        $costo_alquiler = $_POST["costo_alquiler"];
                        $tiempo_minimo = $_POST["tiempo_minimo"];
                        $tiempo_maximo = $_POST["tiempo_maximo"];
                        $cupo = $_POST["cupo"];
                        $fecha_inicio = $_POST["fecha_inicio"];
                        $fecha_fin = $_POST["fecha_fin"];

                        // Validar y procesar los datos (aquí deberías agregar las validaciones necesarias)

                        // Actualizar la oferta en la base de datos
                        $sql = "UPDATE alquileres SET 
                                titulo = '$titulo',
                                descripcion = '$descripcion',
                                ubicacion = '$ubicacion',
                                etiquetas = '$etiquetas',
                                costo_alquiler = '$costo_alquiler',
                                tiempo_minimo = '$tiempo_minimo',
                                tiempo_maximo = '$tiempo_maximo',
                                cupo = '$cupo',
                                fecha_inicio = '$fecha_inicio',
                                fecha_fin = '$fecha_fin'
                                WHERE id = '$id_oferta'";

                        if (mysqli_query($conexion, $sql)) {
                            // La oferta se ha actualizado exitosamente
                            echo '<div class="container mt-4">';
                            echo '<div class="alert alert-success" role="alert">La oferta se ha actualizado exitosamente.</div>';
                            echo '</div>';
                        } else {
                            // Hubo un error al actualizar la oferta
                            echo '<div class="container mt-4">';
                            echo '<div class="alert alert-danger" role="alert">Error al actualizar la oferta: ' . mysqli_error($conexion) . '</div>';
                            echo '</div>';
                        }
                    } else {
                        // Mostrar el formulario de modificación de oferta con todos los campos
                        echo '<div class="container mt-4">';
                        echo '<h1>Modificar Oferta de Alquiler</h1>';
                        echo '<form method="POST">';
                        echo '<div class="form-group">';
                        echo '<label for="titulo">Título</label>';
                        echo '<input type="text" class="form-control" id="titulo" name="titulo" value="' . htmlspecialchars($fila["titulo"]) . '" required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="descripcion">Descripción</label>';
                        echo '<textarea class="form-control" id="descripcion" name="descripcion" required>' . htmlspecialchars($fila["descripcion"]) . '</textarea>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="ubicacion">Ubicación</label>';
                        echo '<input type="text" class="form-control" id="ubicacion" name="ubicacion" value="' . htmlspecialchars($fila["ubicacion"]) . '" required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="etiquetas">Etiquetas</label>';
                        echo '<input type="text" class="form-control" id="etiquetas" name="etiquetas" value="' . htmlspecialchars($fila["etiquetas"]) . '" required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="costo_alquiler">Costo de Alquiler por Día</label>';
                        echo '<input type="number" class="form-control" id="costo_alquiler" name="costo_alquiler" value="' . htmlspecialchars($fila["costo_alquiler"]) . '" required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="tiempo_minimo">Tiempo Mínimo de Permanencia (días)</label>';
                        echo '<input type="number" class="form-control" id="tiempo_minimo" name="tiempo_minimo" value="' . htmlspecialchars($fila["tiempo_minimo"]) . '" required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="tiempo_maximo">Tiempo Máximo de Permanencia (días)</label>';
                        echo '<input type="number" class="form-control" id="tiempo_maximo" name="tiempo_maximo" value="' . htmlspecialchars($fila["tiempo_maximo"]) . '" required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="cupo">Cupo de Personas</label>';
                        echo '<input type="number" class="form-control" id="cupo" name="cupo" value="' . htmlspecialchars($fila["cupo"]) . '" required>';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="fecha_inicio">Fecha de Inicio</label>';
                        echo '<input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio" value="' . ($fila["fecha_inicio"] ? $fila["fecha_inicio"] : "") . '">';
                        echo '</div>';
                        echo '<div class="form-group">';
                        echo '<label for="fecha_fin">Fecha de Fin</label>';
                        echo '<input type="date" class="form-control" id="fecha_fin" name="fecha_fin" value="' . ($fila["fecha_fin"] ? $fila["fecha_fin"] : "") . '">';
                        echo '</div>';
                        echo '<div class="text-center"><button type="submit" class="btn btn-primary">Guardar Cambios</button></div>';
                        echo '</form>';
                        echo '</div>';
                    }
                } else {
                    // El usuario no es el propietario de la oferta
                    echo '<div class="container mt-4">';
                    echo '<div class="alert alert-danger" role="alert">No tienes permiso para modificar esta oferta.</div>';
                    echo '</div>';
                }
            } else {
                // Oferta no encontrada
                echo '<div class="container mt-4">';
                echo '<div class="alert alert-danger" role="alert">Oferta no encontrada.</div>';
                echo '</div>';
            }
        } else {
            // Error en la consulta
            echo '<div class="container mt-4">';
            echo '<div class="alert alert-danger" role="alert">Error en la consulta: ' . mysqli_error($conexion) . '</div>';
            echo '</div>';
        }
        mysqli_stmt_close($stmt);
    }
} else {
    // ID de oferta no válido
    echo '<div class="container mt-4">';
    echo '<div class="alert alert-danger" role="alert">ID de oferta no válido.</div>';
    echo '</div>';
}

// Incluye el pie de página
require_once('footer.php');
?>
